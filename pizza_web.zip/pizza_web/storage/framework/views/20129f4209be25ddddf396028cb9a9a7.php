<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Liste des utilisateurs</h1>
        <?php if(session('etat')): ?>
            <div class="alert alert-success">
                <?php echo e(session('etat')); ?>

            </div>
        <?php endif; ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Login</th>
                    <th>Type</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->nom); ?></td>
                        <td><?php echo e($user->prenom); ?></td>
                        <td><?php echo e($user->login); ?></td>
                        <td><?php echo e($user->type); ?></td>
                        <td>
                            <?php if($user->type != 'admin'): ?>
                                <a href="<?php echo e(route('users.delete', ['id' => $user->id])); ?>" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ?')">Supprimer</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('trame.modele', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nassimmadi/Documents/pizza_web/resources/views/supp_compte.blade.php ENDPATH**/ ?>