

<?php $__env->startSection('title','Détail'); ?>

<?php $__env->startSection('contenu'); ?>

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css"
    integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<style>
.table-detail-commande {
    font-family: Arial, sans-serif;
    border-collapse: collapse;
    width: 30%;
    margin: 50px auto 20px auto;
    margin-top: 35px;

}

.table-detail-commande td,
.table-detail-commande th {
    border: 1px solid #ddd;
    padding: 8px;
}

.table-detail-commande tr:nth-child(even) {
    background-color: #f2f2f2;
}

.table-detail-commande th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: center;
    background-color: #4CAF50;
    color: white;
}

.table-detail-commande a {
    color: #4CAF50;
    text-decoration: none;
    margin-top: 20px;
}

.btn-retour {
    margin-top: 20px;
}

.navbar {
    border-radius: 0;
    height: 56px;
}

.fa-home {
    font-size: 1.3em;

}

h2 {

    font-size: 28px;
    font-weight: 700;
    margin-top: 40px;
    text-align: center;
    color: #4CAF50;
}
</style>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <div class="collapse navbar-collapse " id="navb">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link center ml-2" href="<?php echo e(route('home')); ?>">
                            <i class="fa fa-home"></i> <span style="font-size: 16px;">Home</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</body>

<h2 class="text-center mb-4">Détails de la commande n°<?php echo e($id); ?> : </h2>
<table class="table-detail-commande">
    <tr>
        <th nowrap class="text-center">Nom de la pizza</th>
        <th nowrap class="text-center">Quantité commandée</th>
        <?php if($type != 'cook'): ?>
        <th nowrap class="text-center">prix</th>
        <?php endif; ?>
    </tr>
    <?php if($type != 'cook'): ?>
    <?php $__currentLoopData = $pizza; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td nowrap class="text-center"><?php echo e($p->nom); ?></td>
        <td nowrap class="text-center"><?php echo e($qte[$p->id]); ?></td>
        <td nowrap class="text-center"><?php echo e($p->prix * $qte[$p->id]); ?> €</td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td></td>
        <td nowrap class="text-center"><strong>Prix total : </strong></td>
        <td nowrap class="text-center"><strong><?php echo e($total); ?> €</strong></td>
    </tr>
    <?php elseif($type == 'cook'): ?>
    <?php $__currentLoopData = $pizza; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td nowrap class="text-center"><?php echo e($p->nom); ?></td>
        <td nowrap class="text-center"><?php echo e($qte[$p->id]); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</table>
<?php if($type == 'admin'): ?>
<div class="text-center">
    <a href="<?php echo e(URL::previous()); ?>" class="btn btn-secondary mt-3">Retour</a>
</div>
<?php elseif($type == 'user'): ?>
<div class="text-center">
    <a href="<?php echo e(route('commandeEnv')); ?>" class="btn btn-secondary mt-3">Retour</a>
</div>
<?php elseif($type == 'cook'): ?>
<div class="text-center">
    <a href="<?php echo e(URL::previous()); ?>" class="btn btn-secondary mt-3">Retour</a>
</div>
<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('trame.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nassimmadi/Documents/pizza_web2/resources/views/Détail.blade.php ENDPATH**/ ?>